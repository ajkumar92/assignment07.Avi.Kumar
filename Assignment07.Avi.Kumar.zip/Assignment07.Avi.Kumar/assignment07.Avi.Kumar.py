# ------------------------------------------------- #
# Title: Assignment 07: Error Handling using Try, Except & Pickling Module
# Description: script created to utilize the error handling
#              try & exception block statements. These statements
#              utilized functions, lists, dictionaries, filetypes
#              to perform error handling & pickling data types.
# ChangeLog: (Who, When, What)
# Avishek Kumar,<3.6.2023>,Created Script
# ------------------------------------------------- #
import pickle
import sys
# This imports code from another code file!

# Data
#-------------------------------------------- #

# Declare Variables
ToDoFile = "ToDoList.txt"   # An object that represents To Do List
objFile = None #An object that represents a file
strData = ""  # A row of text data from the file
dicRow = {}    # A row of data separated into elements of a dictionary {Task,Priority}
lstTable = []  # A list that acts as a 'table' of rows
strMenu = ""   # A menu of user options
strChoice = "" # A Capture the user option selection
import pickle #import pickle module


# -- Processing -- #
# Step 1 - When the program starts, load any data you have
# in a text file called ToDoList.txt into a python list of dictionaries rows (like Lab 5-2)
#Creates the text file if none exists
objFile = open(ToDoFile,"a")
objFile.close()
#import the text file data and convert to the list table
objFile = open(ToDoFile, "r")
for row in objFile:
    lstRow = row.split(",")
    dicRow = {"Task" : lstRow[0], "Priority" : lstRow[1].strip()}
    lstTable.append(dicRow)


# -- Input/Output -- #
# Step 2 - Display a menu of choices to the user
while (True):
    print("""
    How would you like to alter your To Do List?
    Menu of Options
    1) Show current data
    2) Add New Item.
    3) Remove Existing Item.
    4) Save Data File
    5) Pickle the To Do List
    6) DePickle then Display My List
    7) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 8] - "))
    print()
    # adding a new line for looks
    try:
        # Step 3 - Show the current items in the table
        if (strChoice.strip() == '1'):
            if len(lstTable) == 0:
                # If text file is empty
                print("To Do List is empty")
            else:
                for dicRow in lstTable:
                    # Print the list table
                    print(dicRow["Task"]+","+dicRow["Priority"])

        # Step 4 - Add a new item to the list/Table
        elif (strChoice.strip() == '2'):
            print("Add 'Task' & 'Priority' into To Do List")
            Task = input("Enter Task:")
            Priority = input("Enter Priority:")
            dicRow = {"Task": str(Task).lower(), "Priority": str(Priority).upper()}
            # We add a dictionary row to the list table
            lstTable.append(dicRow)
            continue


        # Step 5 - Remove new item from the list/Table
        elif (strChoice.strip() == '3'):
            if len(lstTable) == 0:
                print("To Do List empty.")
            else:
                strTask = str(input("Which task would you like to remove?:")).lower()
                #for dicRow in lstTable:
                while True:
                    try:
                        for row in lstTable:
                            if row["Task"].lower() == strTask.lower():
                                #remove the item from the list table
                                lstTable.remove(row)
                                print("This item has been removed from your To Do List!")
                    except IndexError:
                        print("This task does not exist in To Do List")
                    else:
                        print("This task does not exist in To Do List")
                    break

        # Step 6 - Save tasks to ToDoToDoList.txt file
        elif (strChoice.strip() == '4'):
            # open the list in a way to able to write code
            objFile = open(ToDoFile, "w")
            # convert lstTable back to dictionary format, then write into text file
            for dicRow in lstTable:
                objFile.write(dicRow["Task"]+","+dicRow["Priority"]+"\n")
            print("To Do List has been updated!")
            continue

        #Step 7 - Pickle My List
        elif(strChoice.strip() == '5'):
            #create separate pickled file, using "write binary" context
            with open('PickleToDoList.txt', 'wb') as f:
                #write the pickled data into the pickled file
                pickle.dump(lstTable, f)
                f.close()

        #Step 8 Depickle and Display list
        elif (strChoice.strip() == '6'):
            # we open the list and read in read binary contaxt
            with open('PickleToDoList.txt', 'rb') as f:
                pickle_ToDoList = pickle.load(f)
                print(pickle_ToDoList)

        #Step 9 - Exit program
        elif (strChoice.strip() == '7'):
            objFile.close()
            # Exit program
            break

    except IndexError:
        print("Please choose from the choices .")
    else:
        print("Please choose from the choices.")

